package com.example.emotion.controller;

import com.example.emotion.model.User;
import com.example.emotion.repo.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserRepository userRepo;
    public AuthController(UserRepository userRepo){this.userRepo = userRepo;}

    @PostMapping("/register")
    public ResponseEntity<Map<String,String>> register(@RequestBody Map<String,String> body){
        String username = body.get("username");
        String email = body.get("email");
        String password = body.get("password");
        Optional<User> exists = userRepo.findByUsernameOrEmail(username,email);
        if(exists.isPresent()){
            return ResponseEntity.badRequest().body(Map.of("error","User exists")); 
        }
        User u = new User();
        u.setUsername(username); u.setEmail(email); u.setHashedPassword("hashed-"+password);
        userRepo.save(u);
        return ResponseEntity.ok(Map.of("access_token","fake-token-user-"+u.getId()));
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String,String>> login(@RequestBody Map<String,String> body){
        String username = body.getOrDefault("username", body.get("email"));
        Optional<User> user = userRepo.findByUsernameOrEmail(username, username);
        if(user.isEmpty()){
            return ResponseEntity.badRequest().body(Map.of("error","Invalid credentials"));
        }
        return ResponseEntity.ok(Map.of("access_token","fake-token-user-"+user.get().getId()));
    }
}
