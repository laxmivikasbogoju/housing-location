package com.example.emotion.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique=true)
    private String username;
    @Column(unique=true)
    private String email;
    private String hashedPassword;

    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getUsername(){return username;}
    public void setUsername(String u){this.username=u;}
    public String getEmail(){return email;}
    public void setEmail(String e){this.email=e;}
    public String getHashedPassword(){return hashedPassword;}
    public void setHashedPassword(String p){this.hashedPassword=p;}
}
