package com.example.emotion.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "emotions")
public class Emotion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private String emotion;
    private Integer confidence;
    private LocalDateTime timestamp;
    private String language;
    private String singer;
    private String recommendations;

    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Long getUserId(){return userId;}
    public void setUserId(Long u){this.userId=u;}
    public String getEmotion(){return emotion;}
    public void setEmotion(String e){this.emotion=e;}
    public Integer getConfidence(){return confidence;}
    public void setConfidence(Integer c){this.confidence=c;}
    public LocalDateTime getTimestamp(){return timestamp;}
    public void setTimestamp(LocalDateTime t){this.timestamp=t;}
    public String getLanguage(){return language;}
    public void setLanguage(String l){this.language=l;}
    public String getSinger(){return singer;}
    public void setSinger(String s){this.singer=s;}
    public String getRecommendations(){return recommendations;}
    public void setRecommendations(String r){this.recommendations=r;}
}
