package com.example.emotion.controller;

import com.example.emotion.model.Emotion;
import com.example.emotion.repo.EmotionRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/emotions")
public class EmotionController {
    private final EmotionRepository repo;
    public EmotionController(EmotionRepository repo){this.repo = repo;}

    @PostMapping
    public ResponseEntity<Emotion> create(@RequestBody Map<String,Object> body){
        Emotion e = new Emotion();
        e.setUserId(Long.valueOf(String.valueOf(body.get("user_id"))));
        e.setEmotion((String)body.get("emotion"));
        e.setConfidence((Integer)(body.get("confidence")==null?0: (Integer)body.get("confidence")));
        e.setTimestamp(LocalDateTime.now());
        repo.save(e);
        return ResponseEntity.ok(e);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<Emotion>> list(@PathVariable Long userId){
        return ResponseEntity.ok(repo.findByUserIdOrderByIdDesc(userId));
    }

    @GetMapping("/stats/{userId}")
    public ResponseEntity<Map<String,Object>> stats(@PathVariable Long userId){
        var list = repo.findByUserIdOrderByIdDesc(userId);
        String most = list.stream().map(Emotion::getEmotion).reduce((a,b)->a).orElse("None");
        return ResponseEntity.ok(Map.of("total_detections", list.size(), "most_common_emotion", most));
    }
}
