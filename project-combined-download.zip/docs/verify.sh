#!/usr/bin/env bash
# Simple verification script - assumes backend is started on localhost:8000
set -e
echo "1) Registering a user..."
curl -s -X POST http://127.0.0.1:8000/api/auth/register -H "Content-Type: application/json" -d '{"username":"testuser","email":"test@example.com","password":"pass"}' || true
echo
echo "2) Logging in..."
curl -s -X POST http://127.0.0.1:8000/api/auth/login -H "Content-Type: application/json" -d '{"username":"testuser","email":"test@example.com","password":"pass"}' || true
echo
echo "3) Creating an emotion entry..."
curl -s -X POST http://127.0.0.1:8000/api/emotions -H "Content-Type: application/json" -d '{"user_id":1,"emotion":"happy","confidence":90}' || true
echo
echo "4) Listing emotions for user 1..."
curl -s http://127.0.0.1:8000/api/emotions/1 || true
echo
echo "5) Getting stats..."
curl -s http://127.0.0.1:8000/api/emotions/stats/1 || true
echo
