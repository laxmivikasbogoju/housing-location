# CHANGELOG

- Created a working FastAPI backend (SQLite) with endpoints:
  - POST /api/auth/register
  - POST /api/auth/login
  - POST /api/emotions
  - GET /api/emotions/{user_id}
  - GET /api/emotions/stats/{user_id}
- Added CORS middleware to allow frontend calls.
- Added .env.example and simple docs/verify.sh for testing.
- Diagnostics.txt documents issues found in the uploaded archive.

- Combined FastAPI and Spring Boot backends into single repo.
