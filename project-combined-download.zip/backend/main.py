from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import datetime
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./test.db")

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True)
    email = Column(String(100), unique=True, index=True)
    hashed_password = Column(String(255))

class Emotion(Base):
    __tablename__ = "emotions"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True)
    emotion = Column(String(50))
    confidence = Column(Integer, default=0)
    timestamp = Column(DateTime, default=datetime.utcnow)
    language = Column(String(50), nullable=True)
    singer = Column(String(100), nullable=True)
    recommendations = Column(Text, nullable=True)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Emotion Backend (fixed)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for dev - restrict in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Schemas
class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class Token(BaseModel):
    access_token: str

class EmotionCreate(BaseModel):
    user_id: int
    emotion: str
    confidence: int = 0
    language: str = None
    singer: str = None

class EmotionOut(BaseModel):
    id: int
    user_id: int
    emotion: str
    confidence: int
    timestamp: datetime
    language: str = None
    singer: str = None
    recommendations: str = None

    class Config:
        orm_mode = True

# Simple in-memory "auth" for demo
def hash_pw(pw: str) -> str:
    return "hashed-" + pw

@app.post("/api/auth/register", response_model=Token)
def register(u: UserCreate):
    db = SessionLocal()
    exists = db.query(User).filter((User.username==u.username)|(User.email==u.email)).first()
    if exists:
        db.close()
        raise HTTPException(status_code=400, detail="User exists")
    user = User(username=u.username, email=u.email, hashed_password=hash_pw(u.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    db.close()
    return {"access_token": f"fake-token-user-{user.id}"}

@app.post("/api/auth/login", response_model=Token)
def login(u: UserCreate):
    # allow login by email
    db = SessionLocal()
    user = db.query(User).filter((User.username==u.username)|(User.email==u.email)).first()
    db.close()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid credentials")
    return {"access_token": f"fake-token-user-{user.id}"}

@app.post("/api/emotions", response_model=EmotionOut)
def create_emotion(e: EmotionCreate):
    db = SessionLocal()
    emo = Emotion(
        user_id=e.user_id, emotion=e.emotion, confidence=e.confidence,
        language=e.language, singer=e.singer, timestamp=datetime.utcnow()
    )
    db.add(emo)
    db.commit()
    db.refresh(emo)
    db.close()
    return emo

@app.get("/api/emotions/{user_id}", response_model=List[EmotionOut])
def list_emotions(user_id: int, skip: int=0, limit: int=20):
    db = SessionLocal()
    rows = db.query(Emotion).filter(Emotion.user_id==user_id).order_by(Emotion.id.desc()).offset(skip).limit(limit).all()
    db.close()
    return rows

@app.get("/api/emotions/stats/{user_id}")
def stats(user_id: int):
    db = SessionLocal()
    total = db.query(Emotion).filter(Emotion.user_id==user_id).count()
    most = db.query(Emotion.emotion).filter(Emotion.user_id==user_id).all()
    db.close()
    most_common = None
    if most:
        from collections import Counter
        most_common = Counter([m[0] for m in most]).most_common(1)[0][0]
    return {"total_detections": total, "most_common_emotion": most_common or "None"}
