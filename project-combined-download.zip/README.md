# Project Fixed - Emotion Based Song Recommendation (Fixed Backend)

This repository contains the original frontend (unchanged) and a fixed backend (FastAPI + SQLite) so the frontend can be integrated locally.

Run steps are in /docs/verify.sh


## Backends Available
- FastAPI backend in /backend (port 8000)
- Spring Boot backend in /backend-springboot (port 8080)
